THE FINAL VERDICT - JOSEPH MAROUN

Upload ALL files in this folder together to a NEW GitHub repository. Enable GitHub Pages: Settings > Pages > Deploy from branch > main / root.

index.html contains the complete original THE VERDICT.docx text. All 11 original evidence photos are included. The soundtrack is loaded from YouTube video 4i9u_hucAUs and is requested when ENTER THE COURTROOM is clicked. Browsers/YouTube may still block playback or embedding. Internet is required for YouTube music.

Keep the filenames unchanged. This website is separate from the investigation form.
